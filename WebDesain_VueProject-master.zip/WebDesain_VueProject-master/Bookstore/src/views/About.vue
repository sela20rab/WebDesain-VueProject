<template>
    <div>
      <h1>About Page</h1>
      <!-- Konten About Page -->
    </div>
  </template>
  
  <script>
  export default {
    name: 'AboutPage',
    // ...
  }
  </script>
  